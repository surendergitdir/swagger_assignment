<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('contacts.create')); ?>" class="btn btn-primary mb-3">Add New Contact</a>

    <form action="<?php echo e(route('contacts.importXml')); ?>" method="POST" enctype="multipart/form-data" class="mb-4">
        <?php echo csrf_field(); ?>
        <div class="input-group">
            <input type="file" name="xml_file" class="form-control" required accept=".xml">
            <button class="btn btn-secondary" type="submit">Import XML</button>
        </div>
    </form>

    <?php if($contacts->count()): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($contact->name); ?></td>
                        <td><?php echo e($contact->phone); ?></td>
                        <td>
                            <a href="<?php echo e(route('contacts.edit', $contact)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('contacts.destroy', $contact)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this contact?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- Pagination links -->
        <div class="mt-4" style='float: right;'>
            <?php echo e($contacts->links('pagination::bootstrap-4')); ?>

        </div>
    <?php else: ?>
        <p>No contacts found.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/check_ttml/contacts-app/contacts-app/resources/views/contacts/index.blade.php ENDPATH**/ ?>