<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Client Hierarchy</h2>
            <div>
                <a href="<?php echo e(route('clients.import.form')); ?>" class="btn btn-primary me-2">Import Clients (CSV)</a>
                <a href="<?php echo e(route('client.create')); ?>" class="btn btn-primary me-2">Add Client</a>
                <a href="<?php echo e(url('swagger/index.html')); ?>" target="_blank" class="btn btn-success">
                    Swagger Docs
                </a>
            </div>
        </div>
        <ul class="list-group">
            <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <strong><?php echo e($person->full_name); ?></strong>
                    <?php if($person->children->isNotEmpty()): ?>
                        <?php echo $__env->make('hierarchy.children', ['children' => $person->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
         <!-- Pagination links -->
         <div class="mt-4" style='float: right;'>
            <?php echo e($client->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/check_ttml/contacts-app/swaggerAssignment/resources/views/hierarchy/index.blade.php ENDPATH**/ ?>