<?php $__env->startSection('content'); ?>
    <h2>Add Client</h2>
    <form action="<?php echo e(route('client.store')); ?>" method="POST" class="row g-3">
        <?php echo csrf_field(); ?>
        <div class="col-md-6">
            <label for="full_name" class="form-label">Full Name*</label>
            <input type="text" name="full_name" class="form-control" required>
        </div>

        <div class="col-md-6">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" class="form-control">
        </div>

        <div class="col-md-6">
            <label for="phone" class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control">
        </div>

        <div class="col-md-6">
            <label for="dob" class="form-label">Date of Birth</label>
            <input type="date" name="dob" class="form-control">
        </div>

        <div class="col-md-6">
            <label for="balance" class="form-label">Balance</label>
            <input type="number" name="balance" step="0.01" class="form-control">
        </div>

        <div class="col-md-6">
            <label for="parent_id" class="form-label">Parent Client (optional)</label>
            <select name="parent_id" class="form-select">
                <option value="">-- None --</option>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->full_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-12">
            <button type="submit" class="btn btn-success">Add Client</button>
            <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary">Back</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/check_ttml/contacts-app/swaggerAssignment/resources/views/hierarchy/create.blade.php ENDPATH**/ ?>