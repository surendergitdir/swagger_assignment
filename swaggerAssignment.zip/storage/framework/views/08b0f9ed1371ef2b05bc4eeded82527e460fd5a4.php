<?php $__env->startSection('content'); ?>
    <h4>Add New Contact</h4>
    <form method="POST" action="<?php echo e(route('contacts.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Name</label>
            <input name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Phone</label>
            <input name="phone" class="form-control">
        </div>
        <button class="btn btn-success">Save</button>
        <a href="<?php echo e(route('contacts.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/check_ttml/contacts-app/contacts-app/resources/views/contacts/create.blade.php ENDPATH**/ ?>