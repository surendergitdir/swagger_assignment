<ul>
    <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($child->full_name); ?>

            <?php if($child->children->isNotEmpty()): ?>
                <?php echo $__env->make('hierarchy.children', ['children' => $child->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH /var/www/html/check_ttml/contacts-app/swaggerAssignment/resources/views/hierarchy/children.blade.php ENDPATH**/ ?>