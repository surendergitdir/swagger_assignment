<?php $__env->startSection('content'); ?>
    <h4>Edit Contact</h4>
    <form method="POST" action="<?php echo e(route('contacts.update', $contact)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label>Name</label>
            <input name="name" value="<?php echo e($contact->name); ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Phone</label>
            <input name="phone" value="<?php echo e($contact->phone); ?>" class="form-control">
        </div>
        <button class="btn btn-success">Update</button>
        <a href="<?php echo e(route('contacts.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/check_ttml/contacts-app/contacts-app/resources/views/contacts/edit.blade.php ENDPATH**/ ?>