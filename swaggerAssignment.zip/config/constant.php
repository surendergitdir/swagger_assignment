<?php

return [
    'MAX_PAGE_SIZE' => 20,
];
